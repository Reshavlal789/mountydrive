$(document).ready(function () {
    $('.toggle-button').on('click', function () {
  
      $('.animated-icon2').toggleClass('open');
    });
  });